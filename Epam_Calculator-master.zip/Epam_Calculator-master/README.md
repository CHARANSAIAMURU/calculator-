# Epam_Calculator
EPAM PEP Program
This is a Maven Java Project task.
This Project made by following the SOLID/DRY/KISS/YAGNI Principles.
