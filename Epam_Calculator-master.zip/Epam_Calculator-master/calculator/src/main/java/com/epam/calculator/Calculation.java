package com.epam.calculator;

public class Calculation {

	public Calculation(double number1, char operator,double number2) {
		
		
	}

}
